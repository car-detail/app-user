import 'dart:convert';
import 'dart:ffi';

import 'package:car_app/Common/Color.dart';
import 'package:car_app/Common/CommonWidget.dart';
import 'package:car_app/Common/Constant.dart';
import 'package:car_app/features/categories_module/ui/categories_list_activity.dart';
import 'package:car_app/features/home_module/data_manager/home_data_manager.dart';
import 'package:car_app/features/home_module/model/offer_list_model.dart';
import 'package:car_app/features/specialists_module/ui/specialists_activity.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../Common/PromoCarousel.dart';

import '../../../Common/CommonBean.dart';
import '../../categories_module/ui/sevice_list_screen.dart';
import '../../notification_model/ui/notification_activity.dart';
import '../model/category_model_data.dart';
import '../model/services_model_data.dart';

class HomeActivity extends StatefulWidget {
  const HomeActivity({super.key});

  @override
  State<HomeActivity> createState() => _HomeActivityState();
}

class _HomeActivityState extends State<HomeActivity> {
  List<CategoryData> categoryData = [];
  List<ServicesData> servicesData = [];
  List<OfferListModelData> offerListData = [];
  HomeDataManager? dataManager;
  SharedPreferences? sharedPreferences;
  List<String> offerList = ["car_image.png", "car_image.png"];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    start();
  }

  start() async {
    sharedPreferences = await SharedPreferences.getInstance();
    dataManager = HomeDataManager(sharedPreferences!);
    getCategory(context);
    getServices(context);
    getOffer(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.only(top: 60, bottom: 10),
            color: ColorClass.base_color,
            child: Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 10),
                  height: 10,
                  width: 10,
                ),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Icon(
                      Icons.location_on_outlined,
                      color: Colors.white,
                      size: 30,
                    ),
                    CommonWidget.getTextWidget500(
                        sharedPreferences?.getString(Constant.location) ?? "",
                        color: Colors.white),
                  ],
                )),
                GestureDetector(
                  onTap: () {
                    CommonWidget.navigateToScreen(
                        context, NotificationActivity());
                  },
                  child: Container(
                      margin: EdgeInsets.only(right: 10),
                      child: Icon(
                        Icons.notifications_active_rounded,
                        color: Colors.white,
                        size: 30,
                      )),
                )
              ],
            ),
          ),
          Expanded(
              child: Container(
            margin: EdgeInsets.only(top: 30, left: 15, right: 15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // CommonWidget.getTextWidget500("Categories"),
                Center(
                  child: Container(
                    height: 120, // Adjust the height if needed
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: ListView.builder(
                      itemCount: categoryData.length,
                      padding: EdgeInsets.symmetric(
                          horizontal:
                              15), // Add padding on left and right for center alignment
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            CommonWidget.navigateToScreen(
                              context,
                              // getServicesNew(context, placeId, lat, lng)
                              CategoriesListActivity(categoryData[index]),
                            );
                          },
                          child: Container(
                            margin: EdgeInsets.only(
                                right: 20), // Spacing between items
                            width: 80, // Adjust the width to suit your design
                            height:
                                100, // Adjust the height to suit your design
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(
                                  12), // Rounded corners for modern design
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 4,
                                  offset: Offset(2, 2),
                                ),
                              ], // Shadow effect for depth
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment
                                  .center, // Centering the contents vertically
                              crossAxisAlignment: CrossAxisAlignment
                                  .center, // Centering the contents horizontally
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(
                                      12), // Rounded image corners
                                  child: Image.network(
                                    categoryData[index].logoImage ?? "",
                                    height: 50,
                                    width: 50,
                                    fit: BoxFit
                                        .contain, // Make sure image fits within the container
                                    color: ColorClass.base_color,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Image.asset(
                                        'assets/images/car_image.png',
                                        fit: BoxFit.contain,
                                        height: 50,
                                        width: 50,
                                      );
                                    },
                                  ),
                                ),
                                SizedBox(
                                    height: 8), // Space between image and text
                                CommonWidget.getTextWidget300(
                                  categoryData[index].categoryTitle ?? "",
                                  14,
                                  color: ColorClass.base_color,
                                  textAlign: TextAlign
                                      .center, // Center text horizontally
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8.0, vertical: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CommonWidget.getTextWidget500("Specialists"),
                      GestureDetector(
                        onTap: () {
                          // Add navigation or action here
                          print("See All tapped");
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8.0, vertical: 4.0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8.0),
                            color: Theme.of(context)
                                .colorScheme
                                .primary
                                .withOpacity(0.1),
                          ),
                          child: Row(
                            children: [
                              Text(
                                "See All",
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w300,
                                      fontSize: 14,
                                      color:
                                          Theme.of(context).colorScheme.primary,
                                    ),
                              ),
                              const SizedBox(width: 4),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 14,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  height: 165,
                  child: ListView.builder(
                      itemCount: servicesData.length,
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            if (servicesData[index].services.length > 0) {
                              CommonWidget.navigateToScreen(
                                  context,
                                   SpecialistsActivity(
                                  servicesData[index].services[0].sId ?? ""),
                                  // SeviceListScreen(
                                  //     servicesData[index].services)
                                      );
                            } else {
                              _showBottomSheet(
                                  servicesData[index].displayName ?? "",
                                  servicesData[index]
                                          .location
                                          ?.coordinates
                                          ?.lat ??
                                      0.0,
                                  servicesData[index]
                                          .location
                                          ?.coordinates
                                          ?.long ??
                                      0.0,
                                  servicesData[index].location?.name ?? "",
                                  servicesData[index].sId ?? "",
                                  servicesData[index].distance ?? 0.0,
                                  servicesData[index].displayPicture ?? "");
                            }
                          },
                          child: Container(
                            margin: EdgeInsets.only(right: 10),
                            width: 110,
                            height: 140,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                ClipRRect(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20)),
                                  child: Image.network(
                                    servicesData[index].displayPicture ?? "",
                                    height: 105,
                                    width: 105,
                                    fit: BoxFit.fill,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Image.asset(
                                        'assets/images/car_image.png',
                                        fit: BoxFit.cover,
                                        height: 100,
                                        width: 100,
                                      );
                                    },
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(
                                      8.0), // Adjust the value as needed
                                  child: CommonWidget.getTextWidget500(
                                    servicesData[index].displayName ?? "",
                                    size: 12,
                                    color: ColorClass.base_color,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                if (servicesData[index].totalReviews != 0 &&
                                    servicesData[index].totalReviews != null)
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Image.asset(
                                        CommonWidget.getImagePath("stars1.png"),
                                        height: 15,
                                        width: 15,
                                      ),
                                      CommonWidget.getTextWidget300(
                                          " ${servicesData[index].averageRating.toString() ?? ""} (${servicesData[index].totalReviews.toString() ?? ""} views)",
                                          10)
                                    ],
                                  ),
                              ],
                            ),
                          ),
                        );
                      }),
                ),
                if (offerListData.length > 0)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CommonWidget.getTextWidget500("Offers"),
                      /*CommonWidget.getTextWidget300("See All", 14,
                        color: ColorClass.base_color)*/
                    ],
                  ),
                if (offerListData.length > 0)
                  Container(
                    height: 150,
                    child: ListView.builder(
                        itemCount: offerListData.length,
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              CommonWidget.navigateToScreen(
                                  context,
                                  SpecialistsActivity(
                                      offerListData[index].service ?? ""));
                            },
                            child: Container(
                              margin: EdgeInsets.only(right: 10),
                              width: 280,
                              child: Stack(
                                children: [
                                  ClipRRect(
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(20)),
                                      child: Image.network(
                                        offerListData[index].image ?? "",
                                        height: 150,
                                        fit: BoxFit.fill,
                                        width: 270,
                                      )),
                                  Align(
                                      alignment: Alignment.bottomLeft,
                                      child: Container(
                                          margin:
                                              EdgeInsets.fromLTRB(0, 0, 0, 0),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                width: double.infinity,
                                                color: Colors.black
                                                    .withOpacity(0.5),
                                                margin:
                                                    EdgeInsets.only(right: 10),
                                                padding: EdgeInsets.only(
                                                  left: 5,
                                                  right: 5,
                                                ),
                                                child: CommonWidget
                                                    .getTextWidget500(
                                                        "Get ${offerListData[index].discount}% off",
                                                        size: 14,
                                                        color: Colors.white,
                                                        textAlign:
                                                            TextAlign.start),
                                              ),
                                              Container(
                                                width: double.infinity,
                                                decoration: BoxDecoration(
                                                    color: Colors.black
                                                        .withOpacity(0.5),
                                                    borderRadius:
                                                        const BorderRadius.only(
                                                      bottomRight:
                                                          Radius.circular(15),
                                                      bottomLeft:
                                                          Radius.circular(15),
                                                    )),
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                padding: const EdgeInsets.only(
                                                    right: 5,
                                                    left: 5,
                                                    bottom: 5),
                                                child: Text(
                                                  maxLines: 2,
                                                  offerListData[index]
                                                          .description ??
                                                      "",
                                                  style: const TextStyle(
                                                    fontFamily: "Pop500",
                                                    color: Colors.white,
                                                    fontSize: 14,
                                                  ),
                                                  textAlign: TextAlign.start,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                            ],
                                          ))),
                                ],
                              ),
                            ),
                          );
                        }),
                  ),
                Container(
                  child: Column(
                    children: [
                      SizedBox(height: 30), // Add spacing from top
                      PromoCarousel(), // 👈 Add the carousel here
                      SizedBox(height: 20),
                      // Other existing widgets...
                    ],
                  ),
                )
              ],
            ),
          ))
        ],
      ),
    );
  }

  void _showBottomSheet(
    String name,
    double lat,
    double lng,
    String address,
    String placeId,
    num distance,
    String? displayPicture,
  ) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      backgroundColor: Colors.white,
      builder: (BuildContext context) {
        return Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (displayPicture != null && displayPicture.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    displayPicture,
                    height: 220,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Image.asset(
                        CommonWidget.getImagePath("loading.png"),
                        height: 220,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      );
                    },
                  ),
                ),
              SizedBox(height: 20),
              Text(
                name,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 8),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      "Address: $address",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[800],
                      ),
                    ),
                  ),
                  SizedBox(width: 8),
                  Text(
                    "${((distance) / 1609.34).toStringAsFixed(2)} miles",
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  )
                ],
              ),
              SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: Icon(Icons.map, color: Colors.white),
                  label: Text("Open in Google Maps",
                      style: TextStyle(color: Colors.white)),
                  onPressed: () => getServicesNew(context, placeId, lat, lng),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 14),
                    backgroundColor: Colors.green[500],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    textStyle: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  getServicesNew(
      BuildContext context, String id, double lat, double lng) async {
    var response = await dataManager!.postPlaceId(context, id);
    var data = CommonBean.fromJson(jsonDecode(response.body));
    if (data.status == "success") {
      CommonWidget.successShowSnackBarFor(context, data.message ?? "");
      openGoogleMapsNavigation(lat, lng);
    } else {
      CommonWidget.errorShowSnackBarFor(context, data.message ?? "");
      openGoogleMapsNavigation(lat, lng);
    }
  }

  void openGoogleMapsNavigation(double lat, double lng) async {
    Uri googleUrl = Uri.parse(
        "https://www.google.com/maps/dir/?api=1&destination=$lat,$lng");

    if (await canLaunchUrl(googleUrl)) {
      await launchUrl(googleUrl);
    } else {
      throw 'Could not open Google Maps.';
    }
  }

  getCategory(BuildContext context) async {
    var response = await dataManager!.getcategory(context);
    var data = CategoryModelData.fromJson(jsonDecode(response.body));
    if (data.status == "success") {
      setState(() {
        categoryData.clear();
        categoryData.addAll(data.data!);
      });
      //CommonWidget.successShowSnackBarFor(context, data.message ?? "");
    } else {
      CommonWidget.errorShowSnackBarFor(context, data.message ?? "");
    }
  }

  getServices(BuildContext context) async {
    var response = await dataManager!.getAllServices(context);
    var data = ServicesModelData.fromJson(jsonDecode(response.body));
    if (data.status == "success") {
      setState(() {
        servicesData.clear();
        servicesData.addAll(data.data!);
      });
      //CommonWidget.successShowSnackBarFor(context, data.message ?? "");
    } else {
      CommonWidget.errorShowSnackBarFor(context, data.message ?? "");
    }
  }

  getOffer(BuildContext context) async {
    var response = await dataManager!.getOffer(context);
    var data = OfferListModelBean.fromJson(jsonDecode(response.body));
    if (data.status == "success") {
      setState(() {
        offerListData.clear();
        offerListData.addAll(data.data!);
      });
      //CommonWidget.successShowSnackBarFor(context, data.message ?? "");
    } else {
      //CommonWidget.errorShowSnackBarFor(context, data.message ?? "");
    }
  }
}
