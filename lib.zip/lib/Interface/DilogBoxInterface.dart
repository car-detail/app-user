class DilogBoxInterface {
  positivefuntion() {}

  negativefuntion() {}
}
